The following files contain the GAUSS code as well as the data to replicate the empirical aplication in:
Sanso, Arag� & Carrion (2002): "Testing for changes in the unconditional variance of financial time series".

You must copy the files ICSS.SRC and VARIANCE.SRC in the SRC folder of the GAUSS root (usually in C:\GAUSS\SRC).

HAN.DAT, SP.DAT, FTSE.DAT and NIK.DAT contain the financial data.

Finaly, EXAMPLE.GSS reads the data, calls the routines and prints the output. You may edit this file and addapt it to your empirical application.



Any comment will be welcome: andreu.sanso@uib.es